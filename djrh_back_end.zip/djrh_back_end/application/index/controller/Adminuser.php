<?php
namespace app\index\controller;
//应用命名空间
use think\Controller;
use think\Db;
use think\Request;
use think\Session;
use think\File;
use think\Validate;
header("Access-Control-Allow-Credentials:true");//表示是否允许发送Cookie*/
header('Access-Control-Allow-Origin:http://localhost:8091');//允许http://localhost:8088的来源访问
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
header('Access-Control-Allow-Methods: GET, POST, PUT,DELETE,OPTIONS');
header("Content-type: text/json; charset=utf-8");
class AdminUser extends Controller
{
    public function login()
    {

        $userName = input('username');
        $passWord = input('password');
        $result = Db::table('djrh_adminuser')->where(['username' => $userName , 'password' => $passWord])->select();
        if($result){
            session('username', $result[0]["username"]);
            session('password', $result[0]["password"]);
            $result = session('username');
        }else{
            $result = null;
        }
        return json_encode($result);
    }


}