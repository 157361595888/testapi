<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
use think\Request;
use think\Session;
use think\File;
use think\Validate;
class Index
{
    public function index()
    {

        return ;
    }
    public function usersbrowse(){
        if(!session('?isNew')){
            session('isNew',false);
            $result = Db::table('numberofusers')->where('Id' , 1)->select();
            $result = $result[0]['number']+1;
            dump($result);
            Db::table('numberofusers')->where('Id', 1)->update(['number' => $result] );
        }
    }
}
